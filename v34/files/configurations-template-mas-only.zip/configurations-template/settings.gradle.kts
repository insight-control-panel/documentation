rootProject.name = "template-configuration"

enableFeaturePreview("TYPESAFE_PROJECT_ACCESSORS")

pluginManagement {
    repositories {
        val insightRepo: String by settings
        maven(url = insightRepo)

        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositories {
        val insightRepo: String by settings
        maven(url = insightRepo)

        mavenCentral()
    }
}

// include("library:business-suite-endpoints")
// include("library:business-suite")

plugins {
    alias(libs.plugins.uploadConfigs)
    alias(libs.plugins.uploadLibs)
}

insight {
    val mwUrl: String? by project
    val s3Url: String? by project
    val s3AccessKey: String? by project
    val s3Secret: String? by project
    val s3BucketPrefix: String? by project

    url = mwUrl
    S3url = s3Url
    S3accessKey = s3AccessKey
    S3secret = s3Secret
    S3bucketPrefix = s3BucketPrefix
}

tasks.named("notifyLibraryRefresh") {
    // dependsOn(":library:business-suite:deployToS3")
}

tasks.create("generate") {
    dependsOn("generateStaticContent")
    dependsOn("generateClientConfig")
    dependsOn("generateConfigurations")
}

tasks.create("upload") {
    dependsOn("generate")
    dependsOn("uploadClientConfig")
    dependsOn("uploadLanguages")
    dependsOn("uploadSuiteConfigurations")
}

tasks.create("uploadLibrary") {
    group = "Upload"
    description = "Build, Deploy & Notify for Library"

    dependsOn(":library:business-suite:deployToS3")
    dependsOn("notifyLibraryRefresh")
}

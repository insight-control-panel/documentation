#!/usr/bin/env bash

DST_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )"/.. >/dev/null 2>&1 && pwd )"
source ${DST_DIR}/.env

ZIP="zip -rq - *"

echo "============"
echo -e "\033[0;36m>   Project: \033[m ${COMPOSE_PROJECT_NAME} on ${PROJECT_HOST}"
cd ${DST_DIR}/../configurations/trees/maximo
echo -en "\033[0;36m> Directory: \033[m " && pwd
echo "============"
echo

${ZIP} | curl $CURL_OPTIONS -k -XPOST --data-binary @- http://${PROJECT_HOST}:8080/insight-server/rest/publish

#EOF